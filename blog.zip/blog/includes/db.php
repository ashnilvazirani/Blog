<?php
define("SERVER","localhost");
define("USER","piyush");
define("PASSWORD","kukreja12");
define("DB","cms");


$connection=mysqli_connect('localhost', 'piyush', 'kukreja123', 'cms');
//if($connection){
//        echo "We are connected";
//}

?>
